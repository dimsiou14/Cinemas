package mainpackage;

public class Admin {
	
	
	
	public void AddUser() {
		
		System.out.println("You have added a new user.");
	}
	
	
	
	public void DeleteUser() {
		
		System.out.println("You have deleted a user.");
	}
	
	
	
	public void AddProgram() {
		
		System.out.println("You have added a new program.");
	}
	
	
	public  void DeleteProgram() {
		
		System.out.println("You have deleted a program.");
	}
	

}
