package mainpackage;

public class Seller {
	
	
	
	
	public void NewClient() {
		
		System.out.println("You have added a new client.");
	}
	
	
	
	public void PrintBill() {
		
		System.out.println("Your bill has been printed.");
	}
	
	
	
	public void ChangeProgram() {
		
		System.out.println("You have changed program in this number.");
	}

}
