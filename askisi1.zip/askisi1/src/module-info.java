module askisi1 {
}